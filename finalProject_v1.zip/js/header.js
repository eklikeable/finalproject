var header = document.querySelector('header'),
  headerHeight = header.offsetHeight,
  subMenu = document.querySelectorAll('.submenu'),
  subMenuHeight = 0;
  logoHeight = document.querySelector('img').offsetHeight;
  nav = document.querySelector('nav'),
  firstMenu = document.querySelectorAll('.firstmenu');

/* 
Var B = A.offsetHeight; // border 까지의 높이
Var B = A.clientHeight; // padding 까지의 높이

변수명 subMenuHeight에 subMenu중에서 가장 높이가 큰 요소의 높이를 구해서 저장
*/
for (var i = 0; i < subMenu.length; i++) {
  if(subMenu[i].offsetHeight > subMenuHeight){
    subMenuHeight += subMenu[i].offsetHeight;
  } 
}

nav.addEventListener('mouseover', function () {
  header.style.height = logoHeight + subMenuHeight + 150 + 'px';
});
nav.addEventListener('mouseout', function () {
  header.style.height = headerHeight + 'px';
});
