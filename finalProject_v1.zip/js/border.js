window.onload = function() {  // 페이지 접속시 자동 실행 (jQuery를 쓰는게 성능면에서 더 좋다고 하지만 안배움...)
  // board의 ul 태그 안에 li 불러오기 (notice, education 각각)
  for(i = 0; i < 4; i++) {
    const board_li = document.createElement("li");
    const anchor = document.createElement('a');
    anchor.href = "#"

    let notice_text = "공지 사항 공지 사항 공지 사항 공지 사항 공지 사항 공지 사항 공지 사항 공지 사항 공지 사항 공지 사항 공지 사항 공지 사항";
    anchor.innerText = notice_text;
    anchor.style.color = '#000000';
    document.getElementById('notice_text').appendChild(board_li).appendChild(anchor);
  }

  for(i = 0; i < 4; i++) {
    const board_li = document.createElement("li");
    const anchor = document.createElement('a');
    anchor.href = "#"

    let edu_text = "교육 정보 교육 정보 교육 정보 교육 정보 교육 정보 교육 정보 교육 정보 교육 정보 교육 정보 교육 정보 교육 정보 교육 정보";
    anchor.innerText = edu_text;
    anchor.style.color = '#000000';
    document.getElementById('edu_text').appendChild(board_li).appendChild(anchor);
  }
}