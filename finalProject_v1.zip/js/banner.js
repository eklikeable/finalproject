// 배너 버튼 클릭->이미지 전환
var num=1;
function func1(n){
  if(n){
      if(num==3) return;
      num++;
  }
  else{
      if(num==1) return;
      num--;
  }
  var x=document.getElementById("photo");
  x.setAttribute("src","img/banner"+num+".png");
}